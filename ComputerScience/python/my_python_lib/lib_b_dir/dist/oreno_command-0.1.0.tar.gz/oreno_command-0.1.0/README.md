# This is the result of my practice of creating a library
## What is it?
I'm trying to make something using twitter and cryptocurrency data
## How to get it?

```
pip install git+https://github.com/seiyamachiii/lib_b
```

